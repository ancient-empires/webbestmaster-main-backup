(function (win) {

	"use strict";
	/*global window */

	win.sections = win.sections || {};

	win.sections.NAMENAMENAMENAMENAME = {
		name: 'NAMENAMENAMENAMENAME',
		lang: 'ru', // ru || en
		//вЂ™ ¬
		questions: [
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			},
			{

			}

		]

	};

}(window));