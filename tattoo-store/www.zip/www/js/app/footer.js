/*jslint white: true, nomen: true */
(function (win) {

	'use strict';
	/*global window */
	/*global */



}(window));