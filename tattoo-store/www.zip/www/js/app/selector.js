/*jslint white: true, nomen: true */
(function (win) {

	'use strict';
	/*global window */
	/*global */

	win.APP = win.APP || {};

	win.APP.selector = {

		mainContent: ''

	};

}(window));