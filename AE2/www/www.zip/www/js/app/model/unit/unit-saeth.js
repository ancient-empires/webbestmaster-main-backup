(function (win) {

	"use strict";
	/*global console, alert, window, document */
	/*global */

	win.APP.BB.Unit.SaethModel =  win.APP.BB.Unit.BaseUnitModel.extend({

		defaults: win.APP.unitMaster.list.saeth

	});

}(window));